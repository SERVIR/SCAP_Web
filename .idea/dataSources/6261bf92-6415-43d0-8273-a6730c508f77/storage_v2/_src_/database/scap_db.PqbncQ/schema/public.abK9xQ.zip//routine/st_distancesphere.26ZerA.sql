create function st_distancesphere(geom1 geometry, geom2 geometry) returns double precision
    immutable
    strict
    parallel safe
    language sql
as
$$select public.ST_distance( public.geography($1), public.geography($2),false)$$;

alter function st_distancesphere(geometry, geometry) owner to scap_admin;

