create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 500
    language sql
as
$$ SELECT public.ST_AsKML($1::public.geometry, 15);  $$;

alter function st_askml(text) owner to scap_admin;

