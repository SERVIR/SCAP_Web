create function st_buffer(text, double precision) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$ SELECT public.ST_Buffer($1::public.geometry, $2);  $$;

alter function st_buffer(text, double precision) owner to scap_admin;

